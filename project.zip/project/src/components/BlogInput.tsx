import React, { useState } from 'react';
import { Link, FileText, Loader2, AlertCircle } from 'lucide-react';

interface BlogInputProps {
  onSubmit: (input: string, isUrl: boolean) => void;
  loading: boolean;
  error: string | null;
}

export const BlogInput: React.FC<BlogInputProps> = ({ onSubmit, loading, error }) => {
  const [input, setInput] = useState('');
  const [inputType, setInputType] = useState<'text' | 'url'>('text');

  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const isUrl = inputType === 'url' && isValidUrl(input);
    onSubmit(input, isUrl);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setInput(value);
    
    // Auto-detect URL
    if (isValidUrl(value) && inputType === 'text') {
      setInputType('url');
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => setInputType('text')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
            inputType === 'text'
              ? 'bg-blue-500 text-white shadow-md'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          <FileText className="h-4 w-4" />
          Text Input
        </button>
        <button
          onClick={() => setInputType('url')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
            inputType === 'url'
              ? 'bg-blue-500 text-white shadow-md'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          <Link className="h-4 w-4" />
          URL Input
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="blog-input" className="block text-sm font-medium text-gray-700 mb-2">
            {inputType === 'url' ? 'Enter Blog URL' : 'Paste Blog Content'}
          </label>
          <textarea
            id="blog-input"
            value={input}
            onChange={handleInputChange}
            placeholder={
              inputType === 'url'
                ? 'https://example.com/blog-post'
                : 'Paste your blog article content here...'
            }
            className="w-full h-48 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none transition-all"
            disabled={loading}
          />
          <div className="flex justify-between items-center mt-2">
            <span className="text-sm text-gray-500">
              {input.length} characters
            </span>
            {inputType === 'text' && (
              <span className="text-sm text-gray-500">
                ~{Math.ceil(input.split(' ').length / 200)} min read
              </span>
            )}
          </div>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
            <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0" />
            <span className="text-red-700">{error}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={!input.trim() || loading}
          className="w-full bg-blue-500 text-white py-3 px-6 rounded-lg font-medium hover:bg-blue-600 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              Generate Summary
            </>
          )}
        </button>
      </form>
    </div>
  );
};