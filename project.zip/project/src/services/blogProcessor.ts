import { BlogSummary } from '../App';

export async function processBlogContent(content: string): Promise<BlogSummary> {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  const words = content.split(/\s+/).filter(word => word.length > 0);
  const wordCount = words.length;
  const readingTime = Math.ceil(wordCount / 200);

  // Extract key sentences for summary
  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 20);
  const keySentences = extractKeySentences(sentences, content);
  
  // Generate summary (aim for under 150 words)
  const summary = generateSummary(keySentences, words);
  
  // Generate discussion points
  const discussionPoints = generateDiscussionPoints(content, keySentences);

  return {
    summary,
    discussionPoints,
    wordCount,
    readingTime
  };
}

function extractKeySentences(sentences: string[], content: string): string[] {
  // Score sentences based on various factors
  const scoredSentences = sentences.map(sentence => {
    let score = 0;
    const words = sentence.toLowerCase().split(/\s+/);
    
    // Favor sentences with common important words
    const importantWords = ['key', 'important', 'main', 'primary', 'essential', 'significant', 'crucial', 'major', 'fundamental'];
    score += words.filter(word => importantWords.includes(word)).length * 2;
    
    // Favor sentences with numbers/statistics
    score += (sentence.match(/\b\d+\b/g) || []).length;
    
    // Favor sentences that appear early in the content
    const position = content.indexOf(sentence) / content.length;
    score += (1 - position) * 2;
    
    // Penalize very short or very long sentences
    if (words.length < 5 || words.length > 30) score -= 1;
    
    return { sentence: sentence.trim(), score };
  });

  // Sort by score and take top sentences
  return scoredSentences
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map(item => item.sentence);
}

function generateSummary(keySentences: string[], allWords: string[]): string {
  // Combine key sentences into a coherent summary
  let summary = keySentences.join('. ');
  
  // If summary is too long, truncate intelligently
  const summaryWords = summary.split(/\s+/);
  if (summaryWords.length > 140) {
    // Take first 140 words and end at sentence boundary
    const truncated = summaryWords.slice(0, 140).join(' ');
    const lastSentenceEnd = truncated.lastIndexOf('.');
    summary = lastSentenceEnd > 0 ? truncated.substring(0, lastSentenceEnd + 1) : truncated + '...';
  }
  
  // Ensure proper punctuation
  if (!summary.endsWith('.') && !summary.endsWith('!') && !summary.endsWith('?')) {
    summary += '.';
  }
  
  return summary;
}

function generateDiscussionPoints(content: string, keySentences: string[]): string[] {
  const discussionPoints: string[] = [];
  
  // Analyze content for different types of discussion points
  const lowerContent = content.toLowerCase();
  
  // Point 1: Opinion/perspective questions
  if (lowerContent.includes('opinion') || lowerContent.includes('believe') || lowerContent.includes('think')) {
    discussionPoints.push("What's your perspective on the main argument presented? Do you agree or disagree with the author's viewpoint?");
  } else if (lowerContent.includes('future') || lowerContent.includes('predict') || lowerContent.includes('expect')) {
    discussionPoints.push("How do you think this topic will evolve in the future? What changes do you anticipate?");
  } else {
    discussionPoints.push("What aspects of this topic do you find most compelling or concerning?");
  }
  
  // Point 2: Personal experience questions
  if (lowerContent.includes('experience') || lowerContent.includes('example') || lowerContent.includes('case')) {
    discussionPoints.push("Have you encountered similar situations or examples in your own experience? Share your story.");
  } else if (lowerContent.includes('challenge') || lowerContent.includes('problem') || lowerContent.includes('issue')) {
    discussionPoints.push("What challenges or solutions related to this topic have you observed in your field or community?");
  } else {
    discussionPoints.push("How does this topic relate to your personal or professional experience?");
  }
  
  // Point 3: Broader implications questions
  if (lowerContent.includes('impact') || lowerContent.includes('effect') || lowerContent.includes('consequence')) {
    discussionPoints.push("What broader implications do you see for society, industry, or your community?");
  } else if (lowerContent.includes('technology') || lowerContent.includes('innovation') || lowerContent.includes('digital')) {
    discussionPoints.push("How might technological advances change how we approach this topic in the coming years?");
  } else {
    discussionPoints.push("What questions does this article raise that deserve further exploration or research?");
  }
  
  return discussionPoints;
}