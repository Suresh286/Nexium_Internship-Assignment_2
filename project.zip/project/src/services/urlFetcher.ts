export async function fetchUrlContent(url: string): Promise<string> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  try {
    // In a real application, you'd use a CORS proxy or server-side API
    // For demo purposes, we'll simulate fetching content
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; BlogSummarizer/1.0)',
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to fetch content: ${response.status} ${response.statusText}`);
    }
    
    const html = await response.text();
    
    // Extract text content from HTML (basic implementation)
    const textContent = extractTextFromHtml(html);
    
    if (textContent.length < 100) {
      throw new Error('Content too short or could not extract meaningful text from URL');
    }
    
    return textContent;
  } catch (error) {
    if (error instanceof Error) {
      // Handle common CORS issues
      if (error.message.includes('CORS') || error.message.includes('Network')) {
        throw new Error('Unable to fetch content due to CORS restrictions. Please try copying the article text directly.');
      }
      throw error;
    }
    throw new Error('Failed to fetch content from URL');
  }
}

function extractTextFromHtml(html: string): string {
  // Create a temporary DOM element to parse HTML
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = html;
  
  // Remove script and style elements
  const scripts = tempDiv.querySelectorAll('script, style, nav, header, footer, aside');
  scripts.forEach(el => el.remove());
  
  // Try to find main content areas
  const contentSelectors = [
    'article',
    '[role="main"]',
    '.content',
    '.post-content',
    '.article-content',
    '.entry-content',
    'main',
    '.main-content'
  ];
  
  let content = '';
  
  for (const selector of contentSelectors) {
    const element = tempDiv.querySelector(selector);
    if (element) {
      content = element.textContent || element.innerText || '';
      break;
    }
  }
  
  // Fallback to body content if no specific content area found
  if (!content) {
    content = tempDiv.textContent || tempDiv.innerText || '';
  }
  
  // Clean up the text
  return content
    .replace(/\s+/g, ' ')
    .replace(/\n+/g, '\n')
    .trim();
}