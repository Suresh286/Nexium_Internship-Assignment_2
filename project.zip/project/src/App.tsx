import React, { useState } from 'react';
import { BookOpen, Link, Copy, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { BlogInput } from './components/BlogInput';
import { SummaryDisplay } from './components/SummaryDisplay';
import { processBlogContent } from './services/blogProcessor';
import { fetchUrlContent } from './services/urlFetcher';

export interface BlogSummary {
  summary: string;
  discussionPoints: string[];
  wordCount: number;
  readingTime: number;
}

function App() {
  const [summary, setSummary] = useState<BlogSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (input: string, isUrl: boolean) => {
    setLoading(true);
    setError(null);
    setSummary(null);

    try {
      let content: string;
      
      if (isUrl) {
        content = await fetchUrlContent(input);
      } else {
        content = input;
      }

      const result = await processBlogContent(content);
      setSummary(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process content');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSummary(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-blue-500 rounded-full">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800">Blog Summarizer</h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Transform any blog article or URL into a concise, engaging summary with discussion points. 
            Perfect for quick reading and sparking meaningful conversations.
          </p>
        </header>

        <div className="max-w-4xl mx-auto">
          {!summary ? (
            <BlogInput 
              onSubmit={handleSubmit} 
              loading={loading}
              error={error}
            />
          ) : (
            <SummaryDisplay 
              summary={summary}
              onReset={handleReset}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;